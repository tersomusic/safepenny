@extends('layout.app')

@section('css')
    <link href="{{ asset('custom/css/index.css') }}" rel="stylesheet" type="text/css">
@endsection

@section('script')
    <script src="{{ asset('custom/js/index.js') }}" type="text/javascript"></script>
@endsection

@section('article')
    <article class="__sp-article">
        <section class="__sp-cen-block">
            <h3> Get 30% of every earning on Our Platform , Invest With SafePenny</h3>
            <h5>Watch Our Safepenny video , this will allow you to earn, learn and progress,
                be Financial free, Less Stress, Easy Understandable platform , Real UI
            </h5>

            <button class="button-success pure-button __sp-primary">Take A Tour</button>
            <button style="margin-left: 10px;" class="pure-button __sp-trans">Sign Me Up Now</button>

            <section class="__sp-connect">
                <div class="__sp-gridd" pure-u-4-5>
                    <div style="background-repeat: no-repeat;
    background-size: cover;" class="__sp1"> </div>
                    <div class="__p2">
                        <h3>Sign up</h3>
                        <h5>Join Safepenny and be rich , on one click to see dashboard.</h5>
                    </div>

                </div>
                <div class="__sp-gridd" pure-u-4-5>

                    <div class="__sp1"></div>
                    <div class="__p2">
                        <h3>Render help</h3>
                        <h5>Allow your earnings to be circled along thr train by our system</h5>
                    </div>

                </div>
                <div class="__sp-gridd" pure-u-4-5>

                    <div class="__sp1"></div>
                    <div class="__p2">
                        <h3>Get Rich</h3>
                        <h5>Receive Payment within Hours, just click on withdraw!</h5>
                    </div>

                </div>

            </section>


            <a class="__sp-chevron"><i class="fa fa-angle-down"></i></a>
        </section>


    </article>
@endsection
@section('footer')
    <div class="blockfoot">
        <div class="roll_hold_list">
            <ul class="__ulplus">
               <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>

            </ul>

            <ul class="__ulplus">
                <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>

            </ul>

            <ul class="__ulplus">
               <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>
                <h6>Tech</h6>


            </ul>

        </div>

    </div>
@endsection