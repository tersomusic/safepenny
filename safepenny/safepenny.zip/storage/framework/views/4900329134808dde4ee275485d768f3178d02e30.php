<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('custom/css/login.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('custom/js/login.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('article'); ?>

    <article class="__sp-article">
        <section class="__sp-cen-block">
            <div class="__sp-boxsigin">
                <h3> LOGIN </h3>

                <form action="" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input class="__b12" type="Email" name="email" placeholder="Email"/>
                    <input class="__b12" type="password" name="password" placeholder="Password"/>
                    <input class="__b13" type="checkbox" name="remember"/> Remember
                    </span>

                    <button class="button-success pure-button __sp-seconday">LOGIN</button>
                </form>

            </div>
        </section>

    </article>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>