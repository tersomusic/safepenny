<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SafePenny</title>

    <!-- Fonts -->
    <link href="" rel="stylesheet" type="text/css">
    <!-- CSS -->
    <link href="<?php echo e(asset('css/pure-release-0.6.2/pure-min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('custom/css/global.css')); ?>" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldContent('css'); ?>
    <!-- Javascript -->
    <script src="<?php echo e(asset('custom/js/global.js')); ?>" type="text/javascript"></script>
    <?php echo $__env->yieldContent('script'); ?>

    <!-- Styles -->
    <style>
    </style>
</head>
<body>
<header class="__sp-header">
    <div class="__sp-container">
        <div class="pure-g">
            <div class="__sp-pure pure-u-1-5">
                <a href="<?php echo e(url('/')); ?>"><img class="__sp-logo" src="<?php echo e(asset('img/logo.png')); ?>"></a>
            </div>
            <div class="__sp-pure pure-u-4-5">
                <div class="__sp-links">
                    <?php if(@$page !== '/'): ?>
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <?php endif; ?>

                    <a href="#">Resources</a>
                        <a href="<?php echo e(url('Dashboard')); ?>">Dashboard</a>
                    <a href="<?php echo e(url('how')); ?>">How it works</a>

                    <?php if(@$page === 'login'): ?>
                        <a class="__sp-active">Login</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('login')); ?>">Login</a>
                    <?php endif; ?>

                    <?php if(@$page !== 'signup'): ?>
                        <a href="<?php echo e(url('signup')); ?>" style="float: none;border: none !important;">
                            <button class="button-success pure-button __sp-primary">SIGN UP</button>
                        </a>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</header>
<?php echo $__env->yieldContent('article'); ?>
</body>
    <?php echo $__env->yieldContent('footer'); ?>
</html>
