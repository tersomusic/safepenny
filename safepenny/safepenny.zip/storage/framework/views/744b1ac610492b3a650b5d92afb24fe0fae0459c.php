<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('custom/css/index.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('custom/css/DashBoard.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('custom/js/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('article'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>