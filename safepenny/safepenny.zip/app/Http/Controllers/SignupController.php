<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class SignupController extends Controller
{
    //
    public function main () {
        return view('signup')->with('page', 'signup');
    }

    public function create(Request $requests){

        $newUser = User::create([
            'name' => $requests->input('name'),
            'email' => $requests->input('email'),
            'password' => $requests->input('password'),
            'phone' => $requests->input('phone'),
            'signUpDate' => time()
        ]);
    }


}
